package ex7;

import java.util.Scanner;

public class Exercicio7 {

	public static void main(String[] args) {
		String[] vetor= new String[10];
		 
		vetor[0]= "banana";
		vetor[1]= "maçã";
		vetor[2]= "morango";
		vetor[3]= "laranja";
		vetor[4]= "caju";
		vetor[5]= "melancia";
		vetor[6]= "tomate";
		vetor[7]= "goiaba";
		vetor[8]= "pocã";
		vetor[9]= "abóbora";
		for (int i = 0; i < 10; i++) {
			System.out.println(vetor[i]);
		
		}
		System.out.println("Tamanho do vetor: " + vetor.length);
		System.out.println("Último elemento: "+ vetor[9]);
	}

}
