package ex3;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		Scanner leitura = new Scanner(System.in);
		
		System.out.println("Informe um valor inteiro");
		Integer valor = Integer.valueOf(leitura.nextLine()); 
		
		if(valor %2==0) {
			System.out.println("par");
		}else {
				System.out.println("ímpar");
			}
		}
	}

