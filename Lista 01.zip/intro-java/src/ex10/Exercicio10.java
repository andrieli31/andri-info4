package ex10;

import java.util.Scanner;

public class Exercicio10 {

	public static void main(String[] args) {

		Scanner leitura = new Scanner(System.in);
		System.out.println("Informe a primeira nota");
		Double nota1 = Double.valueOf(leitura.nextLine());
		System.out.println("Informe a segunda nota");
		Double nota2 = Double.valueOf(leitura.nextLine());
		System.out.println("Informe a terceira nota");
		Double nota3 = Double.valueOf(leitura.nextLine());

		mediaAluno(nota1, nota2, nota3);

	}

	public static Double mediaAluno(Double nota1, Double nota2, Double nota3) {

		Double media;

		media = (nota1 + nota2 + nota3) / 3;
		if (media >= 6) {
			System.out.println("Aprovado(a)!");
		}
		if (media >= 4 && media < 6) {
			System.out.println("Recuperação!");
		}
		if (media < 4) {
			System.out.println("Reprovado(a)!");
		}

		return media;
	}
}