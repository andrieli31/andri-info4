package ex6;

import java.util.Scanner;

public class Exercicios6 {

	public static void main(String[] args) {
		
		Scanner leitura = new Scanner(System.in);
		int [] vetor = new int[10];
		int maior=0;
		int menor=999999;
		
		for (int i = 0; i < vetor.length; i++) {
		System.out.println("Informe um valor inteiro");	
		vetor[i]= Integer.valueOf(leitura.nextLine());
		

		if (vetor[i]>maior) {
			maior= vetor[i];
		}
		if(vetor[i]<menor) {
			menor=vetor[i];
		}

	}
		System.out.println("Maior número: ");
		System.out.println(maior);
		System.out.println("Menor número: ");
		System.out.println(menor);
		
	}

}
