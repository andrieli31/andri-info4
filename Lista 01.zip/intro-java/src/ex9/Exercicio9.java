package ex9;

public class Exercicio9 {

	public Double  valorAbastecimento(Double valorLitro, Double QuantLitros, Double valorFinal) {
	
		valorFinal=0.0;
		if(valorLitro == null) {
			System.out.println("Valor inválido");
		}
		
	if (QuantLitros == null) {
		System.out.println("Quantidade inválida");
	}
		
		
	return valorFinal;
	}
}
