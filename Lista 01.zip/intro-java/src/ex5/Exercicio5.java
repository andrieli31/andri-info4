package ex5;

public class Exercicio5 {

	public static void main(String[] args) {
		
		int num=0;
		while ( num <= 99) {
			System.out.println(num);
			num++;
		}
	}

}
