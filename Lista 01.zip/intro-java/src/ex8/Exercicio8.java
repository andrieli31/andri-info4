package ex8;

import java.util.ArrayList;
import java.util.Scanner;

public class Exercicio8 {

	public static void main(String[] args) {
		Scanner leitura = new Scanner(System.in);
		ArrayList<String> livros = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			System.out.println("informe um livro");
			String livros1 = leitura.nextLine();
			livros.add(livros1);
		}
		for (String livrosLista : livros) {
			System.out.println(livrosLista);
		}
		System.out.println("Tamanho da lista:"+ livros.size());
		System.out.println("Último elemento: "+ livros.get(livros.size()-1));
	}

}
