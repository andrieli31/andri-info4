package ex1;

import java.util.Scanner;

public class Exercicios1 {

	public static void main(String[] args) {
		Scanner leitura = new Scanner(System.in);
		
		System.out.println("Informe seu nome");
		String nome = leitura.nextLine();
		System.out.println(nome);
		
	}

}
